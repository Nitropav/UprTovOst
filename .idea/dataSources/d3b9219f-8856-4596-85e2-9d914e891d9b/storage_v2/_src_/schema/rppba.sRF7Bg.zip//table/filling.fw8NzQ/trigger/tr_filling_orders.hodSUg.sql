create definer = root@localhost trigger tr_filling_orders
    after INSERT
    on filling
    for each row
begin
set @c_id=(select c_id from orders where o_id=new.o_id);
set @l_id=(select l_id from client where c_id=@c_id);
set @dis=(select l_sale from loyalty where l_id=@l_id);
set @cond=(select o_condition from orders where o_id=new.o_id);
set @pri=(select price from product where id=new.id);
update orders set o_cost=o_cost+(@pri*new.f_kol*@dis*@cond) where o_id=new.o_id;
end;

