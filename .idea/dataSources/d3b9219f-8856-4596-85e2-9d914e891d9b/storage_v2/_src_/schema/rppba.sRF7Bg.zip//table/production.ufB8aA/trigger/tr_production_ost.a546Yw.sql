create definer = root@localhost trigger tr_production_ost
    after INSERT
    on production
    for each row
    update residual set r_kol=r_kol+new.kol where id=new.id;

