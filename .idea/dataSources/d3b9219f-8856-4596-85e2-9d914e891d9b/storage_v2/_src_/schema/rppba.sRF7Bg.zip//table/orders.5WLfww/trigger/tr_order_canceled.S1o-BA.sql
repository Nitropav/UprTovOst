create definer = root@localhost trigger tr_order_canceled
    after UPDATE
    on orders
    for each row
begin
if(new.s_id=4)
then
insert into r1
select t1.p_id, t1.kol+t2.kol
from
(select p_id, kol
from residual) t1,
(select p_id, kol
from filling
where o_id=new.o_id) t2
where t1.p_id=t2.p_id;
delete from residual
where p_id in (select p_id
from filling
where o_id=new.o_id);
insert into residual
select p_id, kol from r1;
delete from r1;
end if;
end;

