create definer = root@localhost trigger tr_filling_ost
    after INSERT
    on filling
    for each row
    update residual set r_kol=r_kol-new.f_kol where id=new.id;

